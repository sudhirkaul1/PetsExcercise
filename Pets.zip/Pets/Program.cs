﻿using System;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace Pets
{
    class Program
    {
        static void Main(string[] args)
        {
            pets pet = new pets();
            var pets = pet.getavailablepets();
           // printing the pets 
            string Json = JsonConvert.SerializeObject(pets);
            Console.WriteLine("the pets are" + Json);

            //some mapping needed here
            var reverseOrder = JsonConvert.DeserializeObject<List<pets>>(pets);
            
            reverseOrder.Reverse();
            
            Console.WriteLine("Reverse order = " + reverseOrder);
            
        }
    }
}
