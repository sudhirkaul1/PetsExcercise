using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pets;

namespace unitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            // check there are available pets returned from the class 

            
            pets pets = new pets();
            var resp = pets.getavailablepets();


        }
    }
}
