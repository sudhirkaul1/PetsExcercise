using System;
using System.Net.Http;

public class pets
{

//   [HttpGet]
  public string getavailablepets()
  {
      // should be singleton 
      var httpClient = new HttpClient();
      //authentication should be done via appsettings..
      var url = "https://petstore.swagger.io/v2/pet/findByStatus?status=available";
      var resp = httpClient.GetAsync(url);
      string availablePetsetJson = null;
       
      resp.Wait();
      if (resp.IsCompleted)
      {
          var availablePetsResult = resp.Result;
          if(availablePetsResult.IsSuccessStatusCode)
          {
              var availablePets = availablePetsResult.Content.ReadAsStringAsync();
              availablePets.Wait();
              Console.WriteLine(availablePets.Result);
              availablePetsetJson =  availablePets.Result;
              
          }
            
         
        
      }  
        return availablePetsetJson;
          
  }

     

}